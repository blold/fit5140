//
//  DataCell.swift
//  5140 - ass2
//
//  Created by 李树圆 on 2016/9/30.
//  Copyright © 2016年 yabo. All rights reserved.
//

import UIKit

class DataCell: UITableViewCell {

    @IBOutlet weak var temperatureData: UILabel!
    @IBOutlet weak var pressureData: UILabel!
    @IBOutlet weak var alimeterData: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

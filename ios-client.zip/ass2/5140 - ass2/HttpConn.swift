//
//  HttpConn.swift
//  5140 - ass2
//
//  Created by 李树圆 on 2016/9/30.
//  Copyright © 2016年 yabo. All rights reserved.
//  this method is from https://medium.com/swift-programming/http-in-swift-693b3a7bf086#.3o9we0toq

import UIKit

class HttpConn: NSObject {
    
    public var url:String = "http://118.138.89.207:8082"
    
    // json object parser
    public func JSONParseDict(jsonString:String) -> Dictionary<String, AnyObject> {
        
        if let data: NSData = jsonString.data(
            using: String.Encoding.utf8) as NSData?{
            
            do{
                if let jsonObj = try JSONSerialization.jsonObject(
                    with: data as Data,
                    options: JSONSerialization.ReadingOptions(rawValue: 0)) as? Dictionary<String, AnyObject>{
                    return jsonObj
                }
            }catch{
                print("Error")
            }
        }
        return [String: AnyObject]()
    }
    
    // json array parser
    public func JSONParseArray(string: String) -> [AnyObject]{
        if let data = string.data(using: String.Encoding.utf8){
            
            do{
                
                if let array = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableContainers)  as? [AnyObject] {
                    return array
                }
            }catch{
                
                print("error")
                //handle errors here
                
            }
        }
        return [AnyObject]()
    }
    
    // send the http request
    public func HTTPsendRequest(request: NSMutableURLRequest,
                                callback: @escaping (String, String?) -> Void) {
        
        let task = URLSession.shared.dataTask(
            with: request as URLRequest, completionHandler :
            {
                data, response, error in
                if error != nil {
                    callback("", (error!.localizedDescription) as String)
                } else {
                    callback(
                        NSString(data: data!, encoding: String.Encoding.utf8.rawValue) as! String,
                        nil
                    )
                    print(data)
                }
        })
        
        task.resume()
    }
    
    // handle how to get the json object from the http request
    public func HTTPGetJSON(
        url: String,
        callback: @escaping (Dictionary<String, AnyObject>, String?) -> Void) {
        
        let request = NSMutableURLRequest(url: NSURL(string: url)! as URL)
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        HTTPsendRequest(request: request) {
            (data: String, error: String?) -> Void in
            if error != nil {
                callback(Dictionary<String, AnyObject>(), error)
            } else {
                let jsonObj = self.JSONParseDict(jsonString: data)
                callback(jsonObj, nil)
            }
        }
    }
    
    // handle how to get the json array from the http request
    public func HTTPGetJsonArray(
        url: String,
        callback: @escaping ([AnyObject], String?) -> Void){
        
        let request = NSMutableURLRequest(url: NSURL(string: url)! as URL)
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        HTTPsendRequest(request: request) {
            (data: String, error: String?) -> Void in
            if error != nil {
                callback([AnyObject](), error)
            } else {
                let jsonObj = self.JSONParseArray(string: data)
                callback(jsonObj, nil)
            }
        }
    }
}

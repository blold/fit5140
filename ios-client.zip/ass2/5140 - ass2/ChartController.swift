//
//  ChartController.swift
//  5140 - ass2
//
//  Created by 李树圆 on 2016/10/11.
//  Copyright © 2016年 yabo. All rights reserved.
//

import UIKit
import SwiftCharts
import CoreLocation

class ChartController: UIViewController, CLLocationManagerDelegate {
    
    var http: HttpConn = HttpConn()
    
    var number:String = ""
    
    fileprivate var chart: Chart?
    
    var temperatureArray:NSMutableArray
    var openWeather:Double?
    
    let locationManager = CLLocationManager()
    
    required init?(coder aDecoder: NSCoder) {
        self.temperatureArray = NSMutableArray()
        super.init(coder: aDecoder)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.locationManager.delegate = self
        
        // Ask for Authorisation from the User.
        self.locationManager.requestAlwaysAuthorization()
        
        let currentLocation = self.locationManager.location
        
        self.temperatureFromOpenWeatherApi(latitude: Float((currentLocation?.coordinate.latitude)!), longitude: Float((currentLocation?.coordinate.longitude)!))
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // This method is used to get the data from the sensor and do the json parse
    func dataByNumber() {
        self.http.HTTPGetJsonArray(url: "\(self.http.url)/NUpdateWeather/\(self.number)"){
            (data: [AnyObject], error: String?) -> Void in
            if error != nil {
                // check the connection and back to the original controller
                let alertController = UIAlertController(title: "Error", message: "No connection", preferredStyle: .alert)
                let alertAction = UIAlertAction(title: "OK", style: .default, handler: { (alertAction) in
                    _ = self.navigationController?.popViewController(animated: true)
                })
                alertController.addAction(alertAction)
                self.present(alertController, animated: true, completion: nil)
            }else{
                for element: AnyObject in data {
                    let temperature = element["temperature"] as? String
                    self.temperatureArray.add(temperature!)
                    print("temperature: \(temperature)")
                }
            }
            // draw the line chart
            DispatchQueue.main.async {
                if (self.temperatureArray.count == 0 || self.temperatureArray[0] as! String == "no content"){
                    let alertController = UIAlertController(title: "Error", message: "No data", preferredStyle: .alert)
                    let alertAction = UIAlertAction(title: "OK", style: .default, handler: { (alertAction) in
                        _ = self.navigationController?.popViewController(animated: true)
                    })
                    alertController.addAction(alertAction)
                    self.present(alertController, animated: true, completion: nil)
                }else{
                    self.drawChart(sensor: self.createDataArray(array: self.temperatureArray), current: self.createCurrentArray(current: self.openWeather!, number: self.number))
                }
            }
        }
    }
    
    // This method is used to get the data from the open weather API and do the json parse for the data
    func temperatureFromOpenWeatherApi(latitude: Float, longitude: Float){
        self.http.HTTPGetJSON(url: "http://api.openweathermap.org/data/2.5/weather?lat=\(latitude)&lon=\(longitude)&appid=c9c4dc9a7b57e772f2ff9714b32a05d7") {
            (data: Dictionary<String, AnyObject>, error: String?) -> Void in
            if error != nil {
                print(error)
            } else {
                let main = data["main"] as! NSDictionary
                let currentTemperature = main["temp"] as! Double
                self.openWeather = currentTemperature - 273.15
                print("open weather: \(self.openWeather!)")
            }
            // get the data from the sensor
            self.dataByNumber()
        }
    }
    
    // This method is used to draw the line chart
    // This line chart will cover two different lines: 
    // One shows the open weather api data;
    // The other one shows the latest sensor data.
    // from the cocoapods swiftcharts
    func drawChart(sensor: Array<(Double,Double)>, current: Array<(Double,Double)>){
        let endNumber: Double = Double(self.number)!
        
        let chartConfig = ChartConfigXY(
            chartSettings: ExamplesDefaults.chartSettings,
            xAxisConfig: ChartAxisConfig(from: 0, to: endNumber, by: 5),
            yAxisConfig: ChartAxisConfig(from: 0, to: 30, by: 5),
            xAxisLabelSettings: ExamplesDefaults.labelSettings,
            yAxisLabelSettings: ExamplesDefaults.labelSettings.defaultVertical()
        )
        
        let rect: CGRect = CGRect(x: 0, y: 64, width: 375, height: 554)
        
        let chart = LineChart(
            frame: ExamplesDefaults.chartFrame(rect),
            chartConfig: chartConfig,
            xTitle: "data number",
            yTitle: "Temperature(°C)",
            lines: [
                (chartPoints: sensor, color: UIColor.red),
                (chartPoints: current, color: UIColor.blue)
            ]
        )
        
        self.view.addSubview(chart.view)
        self.chart = chart
    }
    
    // MARK: method to deal with the chart data
    func createDoubleObject(x: Double, y: Double) -> (Double, Double) {
        return (x,y)
    }
    
    func createDataArray(array: NSMutableArray) -> Array<(Double, Double)>{
        var dataArray: Array<(Double, Double)> = Array<(Double, Double)>()
        var i: Double = 1
        for item in array{
            dataArray.append(self.createDoubleObject(x: i, y: Double(item as! String)!))
            i += 1
        }
        return dataArray
    }
    
    func createCurrentArray(current: Double, number: String) -> Array<(Double, Double)> {
        var dataArray: Array<(Double, Double)> = Array<(Double, Double)>()
        let count: Double = Double(number)!
        var i: Double = 1
        while i <= count {
            dataArray.append(self.createDoubleObject(x: i, y: current))
            i += 1
        }
        return dataArray
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

//
//  TemperatureMonitoringController.swift
//  5140 - ass2
//
//  Created by 李树圆 on 2016/10/3.
//  Copyright © 2016年 yabo. All rights reserved.
//
//  This is the controller for user to test the pressure.
//  swiftmqtt is from https://github.com/aciidb0mb3r/SwiftMQTT


import UIKit
import SwiftMQTT
import CoreData

class TemperatureMonitoringController: UIViewController, MQTTSessionDelegate{

    var mqttSession: MQTTSession!
    
    var host: String = "118.138.89.207"
    
    // UI properties
    @IBOutlet weak var currentLabel: UILabel!
    @IBOutlet weak var highestLabel: UILabel!
    
    @IBOutlet weak var progressView: UIProgressView!
    
    var managedObjectContext: NSManagedObjectContext
    
    required init?(coder aDecoder: NSCoder){
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        self.managedObjectContext = appDelegate.persistentContainer.viewContext
        super.init(coder: aDecoder)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.progressView.transform = CGAffineTransform(scaleX: 1.0, y: 3.0)
        
        if (self.getHighestScore() == 0){
            self.highestLabel.text = "30"
        }else{
            self.highestLabel.text = String(self.getHighestScore())
        }
        
        // mqtt method
        self.mqttSession = MQTTSession(host: self.host, port: 1883, clientID: "swift", cleanSession: true, keepAlive: 15, useSSL: false)
        
        mqttSession.delegate = self
        
        self.mqttSession.connect { (succeeded, error) -> Void in
            if succeeded {
                print("Connected!")
            }
        }
        
        self.mqttSession.subscribe(to: "weather", delivering: .atLeastOnce) { (succeeded, error) -> Void in
            if succeeded {
                print("Subscribed!")
            }
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // set up the ratio of the progress view
    func setProgressView(current: Double, highest: Double) {
        let key: Bool = self.compareCurrentAndHighest(current: current, highest: highest)
        if (!key){
            let ratio = current/highest
            self.progressView.progress = Float(ratio)
        }else{
            self.highestLabel.text = String(current)
            self.progressView.progress = Float(1)
        }
    }
    
    // get the highest score from the core data
    func getHighestScore() -> Double {
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Pressure")
        do {
            let results = try self.managedObjectContext.fetch(request)
            if (results.first == nil){
                return 0
            }else{
                let highest = results.first as! Double
                return highest
            }
            
        } catch {
            fatalError("Error is retriving Gorcery items")
        }
    }
    
    // set the highest score in the core data
    func setHighestScore(current: Double) {
        let entityDescription = NSEntityDescription.entity(forEntityName: "Pressure", in: self.managedObjectContext)
        let newObject = NSManagedObject(entity: entityDescription!, insertInto: self.managedObjectContext)
        
        newObject.setValue(current, forKey: "highest")
        
        do {
            try newObject.managedObjectContext?.save()
        } catch  {
            print(error)
        }
    }
    
    // compare current pressure and highest pressure
    func compareCurrentAndHighest(current: Double, highest: Double) -> Bool {
        if (current > highest){
            return true
        }else{
            return false
        }
    }
    
    // Mark: MQTTsessionDelegate
    func mqttDidReceive(message data: Data, in topic: String, from session: MQTTSession) {
        let string = String(data: data, encoding: .utf8)!
        let json = self.JSONParseDictionary(string: string)
        let currentPressure = json["temperature"] as? String
        DispatchQueue.main.async {
            self.currentLabel.text = currentPressure!
            print("current: \(self.currentLabel.text)")
            print("highest: \(self.highestLabel.text)")
            let key: Bool = self.compareCurrentAndHighest(current: Double(self.currentLabel.text!)!, highest: Double(self.highestLabel.text!)!)
            if (key){
                self.setHighestScore(current: Double(self.currentLabel.text!)!)
            }
            self.setProgressView(current: Double(self.currentLabel.text!)!, highest: Double(self.highestLabel.text!)!)
        }
    }
    
    func mqttSocketErrorOccurred(session: MQTTSession) {
        print("Socket Error")
        // check the connection and back to the original controller
        let alertController = UIAlertController(title: "Error", message: "No connection", preferredStyle: .alert)
        let alertAction = UIAlertAction(title: "OK", style: .default, handler: { (alertAction) in
            _ = self.navigationController?.popViewController(animated: true)
        })
        alertController.addAction(alertAction)
        self.present(alertController, animated: true, completion: nil)
    }
    
    func mqttDidDisconnect(session: MQTTSession) {
        print("Session Disconnected.")
    }
    
    // json parser
    func JSONParseDictionary(string: String) -> [String: AnyObject]{
        if let data = string.data(using: String.Encoding.utf8){
            do{
                if let dictionary = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableContainers) as? [String: AnyObject]{
                        return dictionary
                }
            }catch {
                print("error")
            }
        }
        return [String: AnyObject]()
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

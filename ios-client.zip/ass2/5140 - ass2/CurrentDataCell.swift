//
//  CurrentDataCell.swift
//  5140 - ass2
//
//  Created by 李树圆 on 2016/9/30.
//  Copyright © 2016年 yabo. All rights reserved.
//

import UIKit

class CurrentDataCell: UITableViewCell {

    @IBOutlet weak var dataLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

//
//  ColorController.swift
//  5140 - ass2
//
//  Created by 李树圆 on 2016/10/4.
//  Copyright © 2016年 yabo. All rights reserved.
//

import UIKit

class ColorController: UIViewController {

    @IBOutlet weak var button: UIButton!
    
    var http:HttpConn = HttpConn()
    
    // red, green, blue
    var red:String = ""
    var green:String = ""
    var blue:String = ""
    
    // gradientLayer property
    var gradientLayer: CAGradientLayer!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func buttonAction(_ sender: AnyObject) {
        self.http.HTTPGetJSON(url: "\(self.http.url)/testRGBSenser") {
            (data: Dictionary<String, AnyObject>, error: String?) -> Void in
            if error != nil {
                print(error)
                // check the connection and back to the original controller
                let alertController = UIAlertController(title: "Error", message: "No connection", preferredStyle: .alert)
                let alertAction = UIAlertAction(title: "OK", style: .default, handler: nil)
                alertController.addAction(alertAction)
                self.present(alertController, animated: true, completion: nil)
            } else {
                self.red = data["Red"] as! String
                self.green = data["Green"] as! String
                self.blue = data["Blue"] as! String
                
                print("red color: \(self.red)")
                print("green color: \(self.green)")
                print("blue color: \(self.blue)")
                DispatchQueue.main.async {
                    
                    let color: UIColor = UIColor(
                        red: self.convertStringToCGFloat(color: self.red)/256,
                        green: self.convertStringToCGFloat(color: self.green)/256,
                        blue: self.convertStringToCGFloat(color: self.blue)/256,
                        alpha: 1
                    )
                    self.createGradientLayer(color: color)
                    self.view.layer.sublayers?.remove(at: 0)
                    self.view.layer.insertSublayer(self.gradientLayer, at: 0)
                }
            }
            
        }
    }
    
    // convert string to CGFloat method
    func convertStringToCGFloat(color: String) -> CGFloat{
        let n = NumberFormatter().number(from: color)
        let f = CGFloat(n!)
        return f
    }
    
    // create the gradient color layer
    func createGradientLayer(color: UIColor) {
        gradientLayer = CAGradientLayer()
        gradientLayer.frame = self.view.bounds
        gradientLayer.colors = [UIColor.white, color.cgColor, UIColor.white]
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

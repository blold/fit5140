//
//  Env.swift
//  5140 - ass2
//
//  Created by 李树圆 on 2016/10/11.
//  Copyright © 2016年 yabo. All rights reserved.
//

import UIKit

class Env {
    
    static var iPad: Bool {
        return UIDevice.current.userInterfaceIdiom == .pad
    }
}

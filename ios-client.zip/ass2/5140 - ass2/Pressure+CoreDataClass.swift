//
//  Pressure+CoreDataClass.swift
//  5140 - ass2
//
//  Created by 李树圆 on 2016/10/12.
//  Copyright © 2016年 yabo. All rights reserved.
//

import Foundation
import CoreData


public class Pressure: NSManagedObject {

}

/*
    main server for the pi, it contains http and mqtt
    Xuecong Wang
*/

var express = require("express");
var raspi = require("raspi-io");
var five = require("johnny-five");
var app = express();
var fs = require("fs");

var rgbSenser = require('./RGBSenser.js')
var mosca = require('mosca');

//variable to store temperature, pressure, altittude
var thermometer = "nothing";
var pressure = "nothing";
var altimeter = "nothing"

//start the board
var board = new five.Board({
    io: new raspi()
});

//set the ready funtion to board and collect senser data
board.on("ready", function() {
    var multi = new five.Multi({
        controller: "MPL3115A2",

        elevation: 23
    });

    console.log("Server ready to begin processing...");

    multi.on("change", function() {
        console.log("Therometer:celsius: ", this.thermometer.celsius);
        thermometer = this.thermometer.celsius;
        console.log("thermometer-1: ", thermometer)
        console.log("Barometer:pressure = ", this.barometer.pressure);
      	pressure = this.barometer.pressure
        console.log("Altimeter = ", this.altimeter.meters);
        altimeter = this.altimeter.meters

        // get the current data and insert current data into the weather file
        var currentTime = getDateTime();
        insertDataToWeatherFile(currentTime, thermometer, pressure, altimeter);

        // get the data from senser data and pubilsh the data with MQTT
        var returnJson = getSenserData(thermometer, pressure, altimeter);
        publishClient(returnJson);
    });
});

// This responds to test app get funton with weather variable 
app.get('/', function (req, res) {
   console.log("Got a GET request for the homepage");
   console.log("thermometer-2: ", thermometer)
   console.log("pressure: ", pressure)
   console.log("altimeter: ", altimeter)

   var stringArray = [String(thermometer), String(pressure), String(altimeter)];tes
   res.status(200).send(stringArray);

})

// This responds a GET request for the /json, it is to get the temperature, pressure, altimeter
app.get('/json', function (req, res) {
   console.log("Got a GET request for /json");
   
   var jsonArray = {temperature: String(thermometer), pressure: String(pressure), altimeter: String(altimeter)}
   res.status(200).send(JSON.stringify(jsonArray));

})

// This responds a GET request for the /jsonHistoryByN. in order to get data of N update requirement
app.get('/NUpdateWeather/:N', function (req, res) {
  var returnResult = [];
  try{
   console.log("NUpdate");
   var result = readFileByLine("input.txt", req.params.N)
   console.log("result in UNpdate: " + result);
   console.log("result.length in UNpdate: " + result.length)
   
   // check the reture result of weather fiile whethere it is empty or not
   if (result.length < 1){
      console.log("no data for NUpdateWeather")
      // reture the no content json to app
      var noContent = JSON.stringify({time: "noContent", temperature: "noContent", pressure: "noContent", altimeter: "noContent"})
      returnResult.push(JSON.parse(noContent));
   }else{
      for(var i = 0; i < result.length; i++){
        console.log("result in UNpdate(2): " + result[i]);
        returnResult.push(JSON.parse(result[i]));
        }
    }
  }catch(e){
      console.log("errer in /NUpdateWeather/:N" + e);
  }
  
   res.send(returnResult);
})

// This responds a GET request for the /jsonHistoryByN. inorder to get colour data via HTTP
app.get('/NUpdateColour/:N', function (req, res) {
   var returnResult = [];

   try{
      console.log("NUpdate");
   var result = readFileByLine("colour.txt", req.params.N)
   console.log("result in UNpdate: " + result);
   console.log("result.length in UNpdate: " + result.length)
   // check the reture result of colour fiile whether it is empty or not
   if (result.length < 1){
      console.log("no data for NUpdateWeather")
      // reture the no content json to app
      var noContent = JSON.stringify({time: "noContent", temperature: "noContent", pressure: "noContent", altimeter: "noContent"})
      returnResult.push(JSON.parse(noContent));
   }else{
      for(var i = 0; i < result.length; i++){
        console.log("result in UNpdate(2): " + result[i]);
        returnResult.push(JSON.parse(result[i]));
      }

   }

   }catch(e){
      console.log("error in NUpdateColour");
   }
   

   res.send(returnResult);
})

// it is to get the data between the starting time and ending time
app.get('/TimeRange/:startTime/:endTime', function (req, res) {
   console.log("TimeRange");
   console.log('StartTime: ' + req.params.startTime);
   console.log('EndTime: ' + req.params.endTime);

   // get the data by date from input txt
  var returnJsons = getDataByDate1("input.txt", req.params.startTime, req.params.endTime)
  var returnResult = [];
   for(var i = 0; i < returnJsons.length; i++){
        console.log("result in TimeRange: " + returnJsons[i]);
        returnResult.push(JSON.parse(returnJsons[i]));
   }
   res.send(returnResult);
})

// test for the mqtt client
app.get('/testMqttClient', function (req, res) {
   console.log("testMqttClient");
   publishClient('2');
   res.send("test publishClient()!");
})

// http get test for the simulat data of senser
app.get('/testSimulatSenser', function (req, res) {
    setTimeout(function() {
        console.log("testSimulatSenser");
        var returnJson = simulateSenserData()
        res.send(returnJson);
    }, 3000);
})

// http get test for the RGB senser
app.get('/testRGBSenser', function (req, res) {
   console.log("testRGBSenser");
   rgbSenser.captureColours()
   var result = getResultOfColours()
   insertDataToColourfile(JSON.stringify(result));
   res.send(JSON.stringify(result));

})


// get the result of colour
function getResultOfColours(){
    console.log("Login showResultOfColours()")
    var result = rgbSenser.returnColours();
   console.log("result: " + JSON.stringify(result));
   return result;
}

// read file by line and get the result
function readFileByLine(fileName,inputN){

    var returnResult = new Array();
    try{
      // get the data from the file with split(";")
      var array = fs.readFileSync(String(fileName)).toString().split(";");
      console.log('array.length: ' + array.length);

      // set tthe start index for the loop
      var startIndex = array.length - inputN;
      console.log('startIndex: ' + startIndex);
      for (var i = startIndex - 1; i < array.length - 1; i++) {
          console.log('array[i]: ' + array[i]);
          console.log('i: ' + i);
          returnResult.push(array[i]);
      }
        console.log('returnResult: ' + returnResult);
      }catch(e){
        console.log("error in readFileByLine" + e);
    }
  
    return returnResult;
}

// clear all content in the file
function clearContentFile(fileName){
    fs.writeFile(String(fileName), '', function(){
        console.log('Clear all content')
    })
}

// insert data to weather file
function insertDataToWeatherFile(inputTime, inputTemp, inputPres, inputAlti){
    fs.appendFile('input.txt', '{"time":"' + inputTime + '","temperature":"' + inputTemp + '","pressure":"' + inputPres + '","altimeter":"' + inputAlti + '"};', function (err) {
        if (err) throw err;
        console.log('The "data to append" was appended to file!');
    });
}

// insert data to colour file
function insertDataToColourfile(colourJson){

    // append the data to the colour txt with json syntax
    fs.appendFile('colour.txt', String(colourJson) + ";" , function (err) {
        if (err) throw err;
        console.log('The colour data to append was appended to file!');
    });
}

// create file 
function createFile(fileName){
    console.log("Going to write into existing file");
    fs.writeFile(String(fileName),'', function(err) {
    if (err) {
        return console.error('createFile error: ' + err);
        }
    });
}

// check whether there is the file
function checkExistFile(fileName){
  var booleanResult = false;
  // var targetFile = Titanium.Filesystem.getFile(homeDir, 'historyData.txt');
    try{
        booleanResult = fs.existsSync(String(fileName));
    }catch(err){
        console.log('check exist file error: ' + err)
    }
  return booleanResult
}

// get the current date
function getDateTime() {

    var date = new Date();

    var hour = date.getHours();
    hour = (hour < 10 ? "0" : "") + hour;

    var min  = date.getMinutes();
    min = (min < 10 ? "0" : "") + min;

    var sec  = date.getSeconds();
    sec = (sec < 10 ? "0" : "") + sec;

    var year = date.getFullYear();

    var month = date.getMonth() + 1;
    month = (month < 10 ? "0" : "") + month;

    var day  = date.getDate();
    day = (day < 10 ? "0" : "") + day;

    return year + "-" + month + "-" + day + " " + hour + ":" + min + ":" + sec;

}

// get tehe current date
function getDataByDate1(fileName, startTime, endTime){

    var d1 = startTime;
    var d2 = endTime;    

    var array = fs.readFileSync(String(fileName)).toString().split(";");

    console.log('array.length: ' + array.length);
    var getArray = new Array();
    for (var i = 0; i < array.length - 1; i++) {
        console.log('array[i]: ' + array[i]);
        console.log('i: ' + i);
        getArray.push(array[i]);
    }
    console.log('returnResult: in getDataByDate(): ' + getArray);

    var resultArray = new Array();
    for(var j = 0; j < getArray.length; j++){
        console.log('j: ' + j);
        console.log('getArray[j]: ' + getArray[j]);

        if (checkJsonByDate1(getArray[j], d1, d2) == true){
            console.log('checkJsonByDate() is true')
            resultArray.push(getArray[j]);
        }else{
            console.log('checkJsonByDate() is false')
        }
    }

    console.log('resultArray: ' + resultArray);
    return resultArray;
}

// check json result of date
function checkJsonByDate1(inputJson, startTime, endTime){
    console.log('inputJson in checkJsonByDate(): ' + inputJson);
    console.log('startTime in checkJsonByDate(): ' + startTime);
    console.log('endTime in checkJsonByDate(): ' + endTime);
    var checkResult = false;

    var jsonObject = JSON.parse(inputJson);

    console.log('jsonObject in checkJsonByDate(): ' + jsonObject);
    var date = jsonObject["time"];
    console.log('date in checkJsonByDate(): ' + date);
    console.log('date in inputJson: ' + date);
    console.log('startTime: ' + startTime);
    console.log('endTime: ' + endTime);
    if ((date >= startTime) && (date <= endTime)){
        console.log('date is in the inputTime');
        checkResult = true;
    }else{
        console.log('date is not in the range of time')
    }

    return checkResult;
}

// create the server with the port number
var server = app.listen(8082, function () {

   var host = server.address().address
   var port = server.address().port
   console.log("Example app listening at http://%s:%s", host, port)

      if (checkExistFile("input.txt") != false){
 //       clearContentFile();
        console.log(" input.txt File is already created!");
   }else{
        console.log("input.txt File is not created yet!");
        createFile("input.txt");
   }

   if (checkExistFile("colour.txt") != false){
 //       clearContentFile();
        console.log(" colour.txt File is already created!");
   }else{
        console.log("colour.txt File is not created yet!");
        createFile("colour.txt");
   }
})

// simulate teh senser data
function simulatSenserAction(){
    setTimeout(function() {
        var i = 1;
        i++;
        if(i < 50){
            console.log("testSimulatSenser in loop");
            var returnJson = simulateSenserData()
            publishClient(returnJson);
            simulatSenserAction();
        }
    }, 1000); 
}


/**
 * MQtt server section
 **/

 // create the server with port 1883
var MqttServer = new mosca.Server({
    port: 1883
});

//set teh clientConnected
MqttServer.on('clientConnected', function(client){
    console.log('client connected', client.id);
});

/**
 * listen the topic
 **/
 //listen the publish topic
MqttServer.on('published', function(packet, client) {
    var topic = packet.topic;
    console.log('message-arrived--->','topic ='+topic+',message = '+ packet.payload.toString());



});

// set the server ready
MqttServer.on('ready', function(){
    console.log('mqtt is running...');
});

// get the weather senser data
function getSenserData(temper, altim, press){
  var simulTemperture = temper;
  var simulAltim = altim;
  var simulPress = press;
  var json = '{"temperature":"' + simulTemperture + '","pressure":"' + simulAltim + '","altimeter":"' + simulPress + '"}'
  return json;
}

// simulate the weatehr senser data
function simulateSenserData(){
    var simulTemperture = randomIntInc(1,20);
    var simulAltim = randomIntInc(1,20);
    var simulPress = randomIntInc(1,20);
    var json = '{"temperature":"' + simulTemperture + '","pressure":"' + simulAltim + '","altimeter":"' + simulPress + '"}'
    return json;
}

// simulate the RGB sender data
function RGBSenserData(){
    var simulTemperture = randomIntInc(1,20);
    var simulAltim = randomIntInc(1,20);
    var simulPress = randomIntInc(1,20);
    var json = '{"temperature":"' + simulTemperture + '","pressure":"' + simulAltim + '","altimeter":"' + simulPress + '"}'
    return json;
}

// get the random number
function randomIntInc (low, high) {
    return Math.floor(Math.random() * (high - low + 1) + low);
}

// set the pubish client with topic of "topic"
function publishClient(message){
    var mqtt = require('mqtt');
    var client  = mqtt.connect('mqtt://localhost');

    client.on('connect', function () {
        client.publish('weather', message, {retain: false, qa: 1});
        client.end();
    });
}